/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amunit253;

/**
 *
 * @author Aaron Maynard
 * @param <E>
 */
public interface Tree<E> extends Iterable<E> {
	// Return true if the element is in the tree
	public boolean search(E e);

	public boolean insert(E e);

	public boolean delete(E e);

	public void inorder();

	public void postorder();

	public void preorder();

	public void breadthFirstTraversal();

	public int getSize();

	public boolean isEmpty();
}