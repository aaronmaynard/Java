/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amunit255;
import java.util.*;
/**
 *
 * @author User
 */
public class AMUnit255 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
	Integer[] numbers = new Integer[10];
	// Prompt the user to enter 10 integers
	System.out.print("Enter 10 integers: ");
	for (int i = 0; i < numbers.length; i++){
		numbers[i] = input.nextInt();
        }
	// Create Integer Binary Search Tree
	BinarySearchTree<Integer> intTree = new BinarySearchTree<>(numbers);
	// Traverse tree postorder
	System.out.print("Tree postorder: ");
	intTree.postorder();
	System.out.println();
    }   
}