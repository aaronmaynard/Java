/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amunit254;
import java.util.*;
/**
 *
 * @author User
 */
public class AMUnit254 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
	Integer[] numbers = new Integer[10];
	// Prompt the user to enter 10 integers
	System.out.print("Enter 10 integers: ");
	for (int i = 0; i < numbers.length; i++){
		numbers[i] = input.nextInt();
        }
	// Create Integer Binary Search Tree
	BinarySearchTree<Integer> intTree = new BinarySearchTree<>(numbers);
	// Traverse tree preorder
	System.out.print("Tree preorder: ");
	intTree.preorder();
	System.out.println();
    }   
}