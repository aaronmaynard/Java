/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amunit256;

/**
 *
 * @author Aaron Maynard
 */
public class AMUnit256 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Integer[] numbers = {60, 55, 45, 47, 59, 100, 76, 107, 101};
	
	// Create Integer Binary Search Tree
	BinarySearchTree<Integer> intTree = new BinarySearchTree<>(numbers);
	System.out.println("Number of leaf nodes: " + 
		intTree.getNumberOfLeaves());
    }   
}